﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PLCServer.Enums
{
    public enum WorkMode_900U
    {
        SelfCheck,//自检时
        Work//正常工作时
    }
}
