﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PLCServer.Common
{
   public class ApiSetPreAuthDeltaEntity
    {
        public string Number { get; set; }

        public int From { get; set; }

        public int To { get; set; }
    }
}
