﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PLCServer.Common
{
    public class ApiSetCorrectQuantityEntity
    {
        public string Number { get; set; }

        public int Current { get; set; }

        public int Justness { get; set; }
    }
}
