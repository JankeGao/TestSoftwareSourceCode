﻿using System;

namespace PLCServer.PayLoad.API
{
    public class RetriveStatusListPayLoad : IAPIPayload
    {
        //private Dto.RetriveStatusListDto _retriveStatusListDto;
        //public RetriveStatusListPayLoad(Dto.RetriveStatusListDto retriveStatusListDto)
        //{
        //    _retriveStatusListDto = retriveStatusListDto;
        //}

        //public string ToJson() => JsonConvert.SerializeObject(_retriveStatusListDto);
        public string ToJson()
        {
            throw new NotImplementedException();
        }
    }
}
