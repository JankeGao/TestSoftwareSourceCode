﻿namespace PLCServer.PayLoad
{
    public interface IPayload
    {

    }
}
